let startTime = Date.now();
let cachedAuthToken = null;

function getRootDomain(hostname) {
  const parts = hostname.split(".");
  if (parts.length <= 2) return hostname;
  return parts.slice(-2).join(".");
}

// Inject script to capture auth token from page context
const script = document.createElement('script');
script.src = chrome.runtime.getURL('inject.js');
script.onload = function() {
  this.remove();
};
(document.head || document.documentElement).appendChild(script);

// Listen for messages from the injected script (page context) and forward/store token
window.addEventListener('message', (event) => {
  if (event.source !== window) return;
  if (!event.data || event.data.type !== 'SUBVERIS_AUTH_TOKEN') return;

  const token = event.data.token || null;
  const userId = event.data.userId || null;
  console.log('[Extension] Received SUBVERIS_AUTH_TOKEN from page. Forwarding to background and storing locally.');

  if (token) {
    cachedAuthToken = token;
  }

  // Forward to background script for storage (content scripts can't reliably set chrome.storage)
  // Use a timeout to ensure background script is ready
  setTimeout(() => {
    try {
      chrome.runtime.sendMessage({ type: 'SUBVERIS_AUTH_TOKEN', token, userId }, (response) => {
        if (chrome.runtime.lastError) {
          console.warn('[Extension] Background message error:', chrome.runtime.lastError);
        } else {
          console.log('[Extension] Background script storage response:', response);
        }
      });
    } catch (e) {
      console.warn('[Extension] Failed to send message to background:', e);
    }
  }, 100); // Small delay to ensure background is ready
});

// Get auth token from chrome storage (set by inject script via background)
function getAuthToken() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['authToken'], (result) => {
      console.log('[Extension] Auth token check:', result.authToken ? 'FOUND' : 'NOT FOUND');
      if (result.authToken) cachedAuthToken = result.authToken;
      resolve(result.authToken);
    });
  });
}

function sendUsageTracking(domain, timeSpent) {
  const apiUrl = localStorage.getItem('subverisApiUrl') || 'http://localhost:5000';
  const token = cachedAuthToken;

  if (!token) {
    console.log('[Extension] ❌ No auth token available for unload tracking');
    return;
  }

  const payload = JSON.stringify({ domain, timeSpent });
  const url = `${apiUrl}/api/track-usage-by-domain`;

  // Note: sendBeacon doesn't support custom headers like Authorization
  // So we use fetch with keepalive for authenticated requests
  fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: payload,
    keepalive: true
  }).then(response => {
    console.log('[Extension] 📊 Tracking usage response status:', response.status);
    if (!response.ok) {
      console.error('[Extension] ❌ Tracking request failed:', response.status, response.statusText);
    } else {
      console.log('[Extension] ✅ Usage tracking successful for:', domain);
    }
  }).catch(error => {
    console.error('[Extension] Failed unload fetch usage tracking:', error);
  });
}

// Log when script starts
console.log('[Extension] Content script loaded on:', window.location.hostname);

// Initialize auth token immediately
getAuthToken().then(token => {
  if (token) {
    console.log('[Extension] ✅ Auth token loaded on page load');
  } else {
    console.log('[Extension] ⚠️ No auth token available yet - will check at unload');
  }
});

function trackUsageIfNeeded() {
  const endTime = Date.now();
  const timeSpent = Math.round((endTime - startTime) / 1000);

  console.log(`[Extension] Page unload detected. Time spent: ${timeSpent}s on ${window.location.hostname}`);

  if (timeSpent < 10) {
    console.log(`[Extension] ⏭️  Skipping - less than 10 seconds`);
    return;
  }

  const domain = getRootDomain(window.location.hostname);
  console.log(`[Extension] 📊 Tracking usage for domain: ${domain}`);
  sendUsageTracking(domain, timeSpent);
}

window.addEventListener('pagehide', trackUsageIfNeeded);
window.addEventListener('beforeunload', trackUsageIfNeeded);
