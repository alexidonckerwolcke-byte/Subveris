chrome.runtime.onInstalled.addListener(() => {
    console.log('Subveris Usage Tracker Extension Installed');
});

// Listen for messages from content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('[Background] Received message:', request.type, 'from:', sender.url);

  if (request.type === 'GET_AUTH_TOKEN') {
    chrome.storage.local.get(['authToken'], (result) => {
      console.log('[Background] Sending auth token:', result.authToken ? 'FOUND' : 'NOT FOUND');
      sendResponse({ token: result.authToken || null });
    });
    return true; // Keep channel open for async response
  }

  // Store token forwarded from content script (from injected page)
  if (request.type === 'SUBVERIS_AUTH_TOKEN') {
    console.log('[Background] Storing auth token for user:', request.userId);
    chrome.storage.local.set({
      authToken: request.token,
      supabaseUserUUID: request.userId,
    }, () => {
      if (chrome.runtime.lastError) {
        console.error('[Background] Storage error:', chrome.runtime.lastError);
        sendResponse({ success: false, error: chrome.runtime.lastError });
      } else {
        console.log('[Background] ✅ Stored auth token: User ID =', request.userId);
        sendResponse({ success: true, stored: true });
      }
    });
    return true; // Keep channel open for async response
  }

  console.log('[Background] Unknown message type:', request.type);
});

// Note: injected page messages are forwarded to background by the content script.
